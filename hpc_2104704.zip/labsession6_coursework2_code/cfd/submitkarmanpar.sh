#!/usr/bin/env bash
#SBATCH --job-name=example-job #job name for tracking
#SBATCH --nodes=4
#SBATCH --partition=cs402 #partition you wish to use
#SBATCH --cpus-per-task=2
#SBATCH --ntasks-per-node=1
#SBATCH --time=00:01:00


make clean karman-par
mpirun -n 4 ./karman-par
