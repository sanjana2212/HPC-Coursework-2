void apply_boundary_conditions(float **u, float **v, char **flag,
    int imax, int jmax, float ui, float vi);
