#!/bin/bash
#SBATCH --job-name=example-job
#SBATCH --partition=cs402
#SBATCH --nodes=2
#SBATCH --ntasks=2
#SBATCH --time=00:01:00

. /etc/profile.d/modules.sh

module purge
module load cs402-mpi
time ./karman